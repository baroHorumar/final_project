<?php
// database hostname, you don't usually need to change this
define('db_host','localhost');
// database username
define('db_user','root');
// database password
define('db_pass','');
// database name
define('db_name','comments_php');
// database charset, change this only if utf8 is not supported by your language
define('db_charset','utf8');
// Admin credentials
// Admin username
define('admin_user','admin');
// Admin password
define('admin_pass','admin');
// Approval required for comments?
define('comments_approval_required',false);
// Default profile image
define('default_profile_image','default-profile-image.png');
?>
