<?php
include 'main.php';
// Default filter values
$filter = [
    'word' => '',
    'replacement' => ''
];
if (isset($_GET['id'])) {
    // Retrieve the filter from the database
    $stmt = $pdo->prepare('SELECT * FROM filters WHERE id = ?');
    $stmt->execute([ $_GET['id'] ]);
    $filter = $stmt->fetch(PDO::FETCH_ASSOC);
    // ID param exists, edit an existing filter
    $page = 'Edit';
    if (isset($_POST['submit'])) {
        // Update the filter
        $stmt = $pdo->prepare('UPDATE filters SET word = ?, replacement = ? WHERE id = ?');
        $stmt->execute([ $_POST['word'], $_POST['replacement'], $_GET['id'] ]);
        header('Location: filters.php');
        exit;
    }
    if (isset($_POST['delete'])) {
        // Delete the filter
        $stmt = $pdo->prepare('DELETE FROM filters WHERE id = ?');
        $stmt->execute([ $_GET['id'] ]);
        header('Location: filters.php');
        exit;
    }
} else {
    // Create a new filter
    $page = 'Create';
    if (isset($_POST['submit'])) {
        $stmt = $pdo->prepare('INSERT INTO filters (word,replacement) VALUES (?,?)');
        $stmt->execute([ $_POST['word'], $_POST['replacement'] ]);
        header('Location: filters.php');
        exit;
    }
}
?>
<?=template_admin_header($page . ' Filter', 'filters')?>

<h2><?=$page?> Filter</h2>

<div class="content-block">

    <form action="" method="post" class="form responsive-width-100">

        <label for="word">Word</label>
        <input id="word" type="text" name="word" placeholder="Word" value="<?=$filter['word']?>" required>

        <label for="replacement">Replacement</label>
        <input id="replacement" type="text" name="replacement" placeholder="Replacement" value="<?=$filter['replacement']?>" required>

        <div class="submit-btns">
            <input type="submit" name="submit" value="Submit">
            <?php if ($page == 'Edit'): ?>
            <input type="submit" name="delete" value="Delete" class="delete">
            <?php endif; ?>
        </div>

    </form>

</div>

<?=template_admin_footer()?>
