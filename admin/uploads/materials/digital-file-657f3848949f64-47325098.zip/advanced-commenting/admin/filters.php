<?php
include 'main.php';
// SQL query that will retrieve all the filters from the database ordered by the ID column
$stmt = $pdo->prepare('SELECT * FROM filters ORDER BY id DESC');
$stmt->execute();
$filters = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?=template_admin_header('Filters', 'filters')?>

<h2>Filters</h2>

<div class="links">
    <a href="filter.php">Create Filter</a>
</div>

<div class="content-block">
    <div class="table">
        <table>
            <thead>
                <tr>
                    <td>#</td>
                    <td>Word</td>
                    <td>Replacement</td>
                    <td>Actions</td>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($filters)): ?>
                <tr>
                    <td colspan="4" style="text-align:center;">There are no filters</td>
                </tr>
                <?php else: ?>
                <?php foreach ($filters as $filter): ?>
                <tr>
                    <td><?=$filter['id']?></td>
                    <td><?=htmlspecialchars($filter['word'], ENT_QUOTES)?></td>
                    <td><?=htmlspecialchars($filter['replacement'], ENT_QUOTES)?></td>
                    <td><a href="filter.php?id=<?=$filter['id']?>">Edit</a></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?=template_admin_footer()?>
