<?php
include 'main.php';
?>
<?=template_admin_header('About', 'about')?>

<h2>About</h2>

<div class="content-block">

    <p>The commenting system is fast and secure. You will receive a licence key for the code in the package. The code will monitor on the browser if it is used by someone else.<a href="https://jdelstore.com/reviews-system-in-php-with-mysql-database-31" target="_blank"> Jdelstore</a>.</p>

    <p>Great Code <b>Thank You!</b>. For support, click <a href="https://jdelstore.com/help-center" target="_blank">here</a>.</p>

</div>

<?=template_admin_footer()?>
